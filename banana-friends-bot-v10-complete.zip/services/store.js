const fs = require('fs');
const path = require('path');
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const DEFAULT_DB = {
  users:{}, admins:[], blacklist:{}, mutes:{}, keywords:{
    '群規':'📜 群規：請尊重彼此、禁止騷擾、禁止廣告、禁止洗版。',
    '社群日':'🎮 Pokémon GO 社群日資訊可由後台更新。'
  },
  settings:{
    dailyExp:10,dailyCoins:20,chatExp:2,chatCoins:1,chatCooldown:30,
    adminPassword:'banana123', adminBindCode:'banana2026',
    welcome:'歡迎加入 🍌〔蕉〕個朋友吧！\n輸入「教學」查看指令。',
    rules:'📜 群規\n1. 尊重彼此\n2. 禁止洗版\n3. 禁止廣告\n4. 禁止騷擾',
    announcement:'目前沒有公告。', antiSpam:true, antiAd:true
  },
  shop:[
    {id:'resign',cat:'香蕉幣商店',name:'補簽卡',price:100,stock:999},
    {id:'title-rainbow',cat:'稱號兌換',name:'彩虹冒險家',price:300,stock:999},
    {id:'effect-rainbow',cat:'特效兌換',name:'彩虹光圈',price:500,stock:999},
    {id:'vip7',cat:'VIP',name:'VIP 7天',price:1500,stock:999},
    {id:'raidpass',cat:'Pokemon GO 道具',name:'遠距團戰券',price:300,stock:999}
  ], logs:[]
};
function ensure(){ if(!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR,{recursive:true}); if(!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB,null,2)); }
function load(){ ensure(); try{return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}catch(e){return JSON.parse(JSON.stringify(DEFAULT_DB));} }
function save(db){ ensure(); fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2)); }
function getUser(id){ const db=load(); if(!db.users[id]){ db.users[id]={id,name:'蕉友',exp:0,coins:0,signDays:0,streak:0,lastSign:'',chatCount:0,lastChatAt:0,lastText:'',title:'初生之蕉',photo:'',bio:'',area:'',interests:'',inventory:[]}; save(db);} return db.users[id]; }
function updateUser(id, patch){ const db=load(); if(!db.users[id]) getUser(id); db.users[id]={...db.users[id],...patch}; save(db); return db.users[id]; }
function addLog(text){ const db=load(); db.logs.unshift({time:new Date().toISOString(),text}); db.logs=db.logs.slice(0,200); save(db); }
module.exports={load,save,getUser,updateUser,addLog};
