const express = require('express');
const line = require('@line/bot-sdk');
const store = require('./services/store');
const levels = require('./services/levels');

const config = {
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET
};

const app = express();
const client = new line.Client(config);

app.use('/admin-static', express.static('public/admin'));
app.use('/admin', require('./routes/admin'));

app.get('/', (req, res) => res.status(200).send('🍌 蕉個朋友 Bot V10 Ultimate running'));

function taiwanToday(){ return new Date().toLocaleDateString('zh-TW',{timeZone:'Asia/Taipei'}); }
function uid(event){ return event.source.userId || event.source.groupId || 'unknown'; }
function isAdmin(id){ const db=store.load(); return db.admins.includes(id); }
function textReply(token,text){ return client.replyMessage(token,{type:'text',text}); }
function profileFlex(user){
  const level=levels.getLevel(user.exp); const next=levels.getNextExp(level);
  return {type:'flex',altText:`${user.name} Lv.${level} 名片`,contents:{type:'bubble',hero:{type:'image',url:user.photo||levels.getBadgeUrl(level),size:'full',aspectRatio:'1:1',aspectMode:'cover'},body:{type:'box',layout:'vertical',contents:[
    {type:'text',text:'🍌〔蕉〕個朋友吧！',weight:'bold',size:'lg'},
    {type:'text',text:`👤 ${user.name||'蕉友'}`,margin:'md'},
    {type:'text',text:`🏅 Lv.${level}｜${levels.getTitle(level)}`,weight:'bold',size:'xl',margin:'md'},
    {type:'text',text:`⭐ EXP：${user.exp} / ${next}`,margin:'sm'},
    {type:'text',text:`🍌 香蕉幣：${user.coins}`,margin:'sm'},
    {type:'text',text:`✅ 簽到：${user.signDays} 天｜🔥 連續：${user.streak||0} 天`,margin:'sm'},
    {type:'text',text:`💬 聊天：${user.chatCount||0} 則`,margin:'sm'},
    {type:'text',text:`📍 ${user.area||'未設定'}｜🎮 ${user.interests||'未設定'}`,margin:'sm',wrap:true},
    {type:'text',text:`💭 ${user.bio||'還沒有自介'}`,margin:'sm',wrap:true,color:'#666666'}
  ]}}};
}
function levelUpFlex(user,oldLevel,newLevel){return {type:'flex',altText:`升級到 Lv.${newLevel}`,contents:{type:'bubble',hero:{type:'image',url:levels.getBadgeUrl(newLevel),size:'full',aspectRatio:'1:1',aspectMode:'cover'},body:{type:'box',layout:'vertical',contents:[{type:'text',text:'🎉 等級提升！',weight:'bold',size:'xl'},{type:'text',text:`${user.name||'蕉友'} Lv.${oldLevel} ➜ Lv.${newLevel}`,margin:'md'},{type:'text',text:`🏅 ${levels.getTitle(newLevel)}`,margin:'md',weight:'bold'},{type:'text',text:'🍌 恭喜獲得新徽章！',margin:'md'}]}}};}
async function addExp(event,user,amount,coins=0){
  const old=levels.getLevel(user.exp); user.exp+=Number(amount||0); user.coins+=Number(coins||0); user.title=levels.getTitle(levels.getLevel(user.exp)); store.updateUser(user.id,user); const now=levels.getLevel(user.exp); if(now>old) return client.replyMessage(event.replyToken,levelUpFlex(user,old,now));
}
function helpText(){return `🍌〔蕉〕個朋友吧！指令教學\n\n👤 個人：簽到、我的資料、名片、我的背包、修改名片 欄位 內容\n🏆 排行：排行榜、聊天排行、香蕉幣排行\n🎁 商店：商店、購買 商品名稱\n🎮 Pokemon GO：社群日、團體戰、兌換碼\n📜 群組：群規、公告\n👮 管理：我的ID、綁定管理員 驗證碼、/公告 內容、/黑名單 UserID、/解除黑名單 UserID、/送幣 UserID 數量、/加EXP UserID 數量`;}

async function handleEvent(event){
  if(event.type==='follow' || event.type==='join'){ const db=store.load(); return textReply(event.replyToken, db.settings.welcome); }
  if(event.type!=='message' || event.message.type!=='text') return null;
  const id=uid(event); const db=store.load();
  if(db.blacklist[id]) return null;
  const user=store.getUser(id); const text=event.message.text.trim();

  if(text==='我的ID') return textReply(event.replyToken,`你的 UserID：\n${id}`);
  if(text.startsWith('綁定管理員')){ const code=text.split(/\s+/)[1]; if(code && code===db.settings.adminBindCode){ if(!db.admins.includes(id)) db.admins.push(id); store.save(db); return textReply(event.replyToken,'✅ 已綁定為管理員'); } return textReply(event.replyToken,'❌ 驗證碼錯誤'); }

  if(text.startsWith('/')){
    if(!isAdmin(id)) return textReply(event.replyToken,'❌ 你不是管理員');
    const parts=text.split(/\s+/); const cmd=parts[0];
    if(cmd==='/公告'){ db.settings.announcement=parts.slice(1).join(' ')||db.settings.announcement; store.save(db); return textReply(event.replyToken,'✅ 公告已更新'); }
    if(cmd==='/黑名單'){ db.blacklist[parts[1]]=true; store.save(db); return textReply(event.replyToken,'✅ 已加入黑名單'); }
    if(cmd==='/解除黑名單'){ delete db.blacklist[parts[1]]; store.save(db); return textReply(event.replyToken,'✅ 已解除黑名單'); }
    if(cmd==='/送幣'){ const target=parts[1], n=Number(parts[2]||0); const u=store.getUser(target); u.coins+=n; store.updateUser(target,u); return textReply(event.replyToken,`✅ 已送出 ${n} 香蕉幣`); }
    if(cmd==='/加EXP'){ const target=parts[1], n=Number(parts[2]||0); const u=store.getUser(target); u.exp+=n; u.title=levels.getTitle(levels.getLevel(u.exp)); store.updateUser(target,u); return textReply(event.replyToken,`✅ 已增加 ${n} EXP`); }
    return textReply(event.replyToken,'未知管理指令');
  }

  if(text==='教學'||text==='幫助'||text==='指令') return textReply(event.replyToken,helpText());
  if(text==='群規') return textReply(event.replyToken,db.settings.rules);
  if(text==='公告') return textReply(event.replyToken,db.settings.announcement);
  if(text==='我的資料'||text==='名片') return client.replyMessage(event.replyToken,profileFlex(user));
  if(text.startsWith('修改名片')){ const [,field,...rest]=text.split(/\s+/); const val=rest.join(' '); const map={暱稱:'name',照片:'photo',地區:'area',興趣:'interests',自介:'bio'}; if(!map[field]) return textReply(event.replyToken,'格式：修改名片 暱稱/照片/地區/興趣/自介 內容'); user[map[field]]=val; store.updateUser(id,user); return textReply(event.replyToken,'✅ 名片已更新'); }
  if(text==='簽到'){
    const today=taiwanToday(); if(user.lastSign===today) return textReply(event.replyToken,`今天已簽到過囉 🍌\nLv.${levels.getLevel(user.exp)}｜EXP ${user.exp}｜香蕉幣 ${user.coins}`);
    user.lastSign=today; user.signDays+=1; user.streak=(user.streak||0)+1; store.updateUser(id,user); await addExp(event,user,db.settings.dailyExp,db.settings.dailyCoins); return textReply(event.replyToken,`🍌 簽到成功！\n+${db.settings.dailyExp} EXP｜+${db.settings.dailyCoins} 香蕉幣\n累積簽到：${user.signDays} 天\nLv.${levels.getLevel(user.exp)}｜${levels.getTitle(levels.getLevel(user.exp))}`);
  }
  if(text==='排行榜'||text==='等級排行'){
    const rows=Object.values(db.users).sort((a,b)=>b.exp-a.exp).slice(0,10).map((u,i)=>`${i+1}. ${u.name}｜Lv.${levels.getLevel(u.exp)}｜${u.exp} EXP`).join('\n');
    return textReply(event.replyToken, rows?`🏆 等級排行榜\n\n${rows}`:'目前沒有資料');
  }
  if(text==='聊天排行'){
    const rows=Object.values(db.users).sort((a,b)=>(b.chatCount||0)-(a.chatCount||0)).slice(0,10).map((u,i)=>`${i+1}. ${u.name}｜${u.chatCount||0} 則`).join('\n');
    return textReply(event.replyToken, rows?`💬 聊天排行\n\n${rows}`:'目前沒有資料');
  }
  if(text==='香蕉幣排行'){
    const rows=Object.values(db.users).sort((a,b)=>b.coins-a.coins).slice(0,10).map((u,i)=>`${i+1}. ${u.name}｜🍌 ${u.coins}`).join('\n');
    return textReply(event.replyToken, rows?`🍌 香蕉幣排行\n\n${rows}`:'目前沒有資料');
  }
  if(text==='商店'){
    const rows=db.shop.map(s=>`【${s.cat}】${s.name}｜${s.price} 幣`).join('\n'); return textReply(event.replyToken,`🎁〔蕉〕個朋友商店\n\n${rows}\n\n輸入：購買 商品名稱`);
  }
  if(text.startsWith('購買 ')){ const name=text.replace('購買 ','').trim(); const item=db.shop.find(s=>s.name===name); if(!item) return textReply(event.replyToken,'找不到商品'); if(user.coins<item.price) return textReply(event.replyToken,'香蕉幣不足'); user.coins-=item.price; user.inventory.push(item.name); store.updateUser(id,user); return textReply(event.replyToken,`✅ 已購買：${item.name}`); }
  if(text==='我的背包') return textReply(event.replyToken,`🎒 我的背包\n${(user.inventory||[]).join('\n')||'目前沒有道具'}`);
  if(text==='社群日') return textReply(event.replyToken,'🎮 Pokémon GO 社群日資訊可於後台更新。');
  if(text==='團體戰') return textReply(event.replyToken,'⚔️ 團體戰資訊可於後台更新。');
  if(text==='兌換碼') return textReply(event.replyToken,'🎟️ 最新兌換碼可於後台更新。');
  if(db.keywords[text]) return textReply(event.replyToken,db.keywords[text]);

  const now=Date.now(); const cooldown=(db.settings.chatCooldown||30)*1000;
  if(now-(user.lastChatAt||0)>cooldown && user.lastText!==text){ user.chatCount=(user.chatCount||0)+1; user.lastChatAt=now; user.lastText=text; store.updateUser(id,user); await addExp(event,user,db.settings.chatExp,db.settings.chatCoins); }
  return null;
}

app.post('/webhook', line.middleware(config), async (req,res)=>{
  res.status(200).end();
  try{ await Promise.all((req.body.events||[]).map(handleEvent)); }catch(e){ console.error(e); }
});

const port = process.env.PORT || 10000;
app.listen(port,()=>console.log(`蕉個朋友 Bot V10 running on port ${port}`));
