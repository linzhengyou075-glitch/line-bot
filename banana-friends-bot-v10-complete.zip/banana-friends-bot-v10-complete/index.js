const express = require('express');
const line = require('@line/bot-sdk');
const path = require('path');
const adminRouter = require('./routes/admin');
const { store } = require('./services/store');
const { getLevelInfo, addExp } = require('./services/levels');
const { shopText, buyItem } = require('./services/shop');
const { isAdmin, adminCommand } = require('./services/adminCommands');
const { settings } = require('./services/settings');

const app = express();
const config = { channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN, channelSecret: process.env.CHANNEL_SECRET };
const client = new line.Client(config);

app.use(express.json());
app.use('/admin', adminRouter);
app.use('/admin-static', express.static(path.join(__dirname, 'public/admin')));

function today(){ return new Date().toLocaleDateString('zh-TW',{timeZone:'Asia/Taipei'}); }
function textReply(replyToken, text){ return client.replyMessage(replyToken,{type:'text',text}); }
function userKey(event){ return event.source.userId || event.source.groupId || 'unknown'; }
function ensureUser(event){
  const id=userKey(event); const u=store.users[id] || {id,name:'蕉友',exp:0,coins:0,signDays:0,streak:0,lastSign:'',chat:0,title:'新芽',mutedUntil:0,blacklisted:false,card:{nickname:'蕉友',area:'',age:'保密',intro:'',interest:'',photo:''},bag:[]};
  store.users[id]=u; return u;
}
function badgeFlex(user){
 const lv=getLevelInfo(user.exp); const img=user.card?.photo || settings.badgeBaseUrl.replace('{level}', lv.level);
 return {type:'flex',altText:`${user.name} Lv.${lv.level}`,contents:{type:'bubble',hero:{type:'image',url:img,size:'full',aspectRatio:'1:1',aspectMode:'cover'},body:{type:'box',layout:'vertical',contents:[{type:'text',text:'🍌〔蕉〕個朋友吧！',weight:'bold',size:'lg'},{type:'text',text:`👤 ${user.card?.nickname||user.name}`,margin:'md'},{type:'text',text:`🏅 Lv.${lv.level}｜${lv.title}`,weight:'bold',size:'xl',margin:'md'},{type:'text',text:`⭐ EXP：${user.exp} / ${lv.nextExp}`,margin:'sm'},{type:'text',text:`🍌 香蕉幣：${user.coins}`,margin:'sm'},{type:'text',text:`✅ 簽到：${user.signDays} 天｜🔥 ${user.streak} 天`,margin:'sm'},{type:'text',text:`💬 聊天：${user.chat}`,margin:'sm'}]}}};
}
async function handleEvent(event){
 if(event.type==='join'||event.type==='follow') return textReply(event.replyToken, settings.welcome);
 if(event.type!=='message') return;
 const u=ensureUser(event); if(u.blacklisted) return;
 const now=Date.now(); if(u.mutedUntil && u.mutedUntil>now) return;
 const msg=event.message; const text=(msg.text||'').trim();
 if(msg.type==='text'){
   const ad=/(https?:\/\/|line\.me|discord\.gg|t\.me)/i.test(text); if(settings.antiAd && ad) return textReply(event.replyToken,'⚠️ 請勿張貼廣告或邀請連結。');
   if(text.startsWith('/')) return textReply(event.replyToken, adminCommand(text,event.source.userId));
   if(text==='指令'||text==='教學'||text==='幫助') return textReply(event.replyToken, settings.help);
   if(text==='群規') return textReply(event.replyToken, settings.rules);
   if(text==='商店') return textReply(event.replyToken, shopText());
   if(text.startsWith('購買 ')||text.startsWith('兌換 ')) return textReply(event.replyToken, buyItem(u,text.replace(/^購買 |^兌換 /,'')));
   if(text==='我的背包') return textReply(event.replyToken, `🎒 我的背包\n\n${(u.bag||[]).join('\n')||'目前沒有物品'}`);
   if(text==='簽到'){
     const d=today(); if(u.lastSign===d) return textReply(event.replyToken,`你今天已經簽到過囉 🍌\nLv.${getLevelInfo(u.exp).level}｜EXP ${u.exp}`);
     u.lastSign=d; u.signDays++; u.streak++; u.coins+=settings.signCoins; const before=getLevelInfo(u.exp).level; addExp(u,settings.signExp); store.save(); const after=getLevelInfo(u.exp).level;
     return client.replyMessage(event.replyToken,[{type:'text',text:`🍌 簽到成功！\n⭐ +${settings.signExp} EXP\n🍌 +${settings.signCoins} 香蕉幣\n🔥 連續簽到：${u.streak} 天`}, badgeFlex(u)]);
   }
   if(text==='我的資料'||text==='名片'||text==='我的徽章') return client.replyMessage(event.replyToken,badgeFlex(u));
   if(text.startsWith('修改名片 ')){ const [,field,...rest]=text.split(' '); const val=rest.join(' '); const map={暱稱:'nickname',地區:'area',年齡:'age',興趣:'interest',自介:'intro',照片:'photo'}; if(!map[field]) return textReply(event.replyToken,'格式：修改名片 暱稱 佑佑'); u.card[map[field]]=val; if(field==='暱稱') u.name=val; store.save(); return textReply(event.replyToken,'✅ 名片已更新'); }
   if(text==='排行榜'){ const r=Object.values(store.users).sort((a,b)=>b.exp-a.exp).slice(0,10).map((x,i)=>`${i+1}. ${x.card?.nickname||x.name}｜Lv.${getLevelInfo(x.exp).level}｜${x.exp} EXP`).join('\n'); return textReply(event.replyToken,`🏆 等級排行榜\n\n${r||'尚無資料'}`); }
   if(settings.keywords[text]) return textReply(event.replyToken, settings.keywords[text]);
   const last=u.lastChatAt||0; if(now-last>settings.chatCooldown*1000){u.lastChatAt=now; u.chat++; addExp(u,settings.chatExp); u.coins+=settings.chatCoins; store.save();}
 }
}
app.get('/',(req,res)=>res.send('🍌 蕉個朋友 Bot V10 running'));
app.post('/webhook', line.middleware(config), async (req,res)=>{res.status(200).end(); Promise.all((req.body.events||[]).map(handleEvent)).catch(console.error);});
const port=process.env.PORT||10000; app.listen(port,()=>console.log(`香蕉朋友 Bot V10 running on port ${port}`));
