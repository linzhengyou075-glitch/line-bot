const {store}=require('./store');
function isAdmin(uid){return store.admins[uid]||process.env.ADMIN_USER_ID===uid;}
function adminCommand(text,uid){
 if(text.startsWith('/綁定管理員')){const code=text.split(' ')[1]; if(code&&code===process.env.ADMIN_BIND_CODE){store.admins[uid]={role:'owner'};store.save();return '✅ 已綁定超級管理員';} return '驗證碼錯誤';}
 if(!isAdmin(uid)) return '❌ 你不是管理員';
 const p=text.split(' ');
 if(p[0]==='/公告') return `📢 公告\n${p.slice(1).join(' ')||'請輸入公告內容'}`;
 if(p[0]==='/送幣'){const id=p[1],n=Number(p[2]||0); if(store.users[id]){store.users[id].coins+=n;store.save();return '✅ 已送幣';} return '找不到會員';}
 if(p[0]==='/加EXP'){const id=p[1],n=Number(p[2]||0); if(store.users[id]){store.users[id].exp+=n;store.save();return '✅ 已加 EXP';} return '找不到會員';}
 if(p[0]==='/黑名單'){const id=p[1]; if(store.users[id]){store.users[id].blacklisted=true;store.save();return '✅ 已加入黑名單';} return '找不到會員';}
 if(p[0]==='/解除黑名單'){const id=p[1]; if(store.users[id]){store.users[id].blacklisted=false;store.save();return '✅ 已解除黑名單';} return '找不到會員';}
 if(p[0]==='/禁言'){const id=p[1],min=Number(p[2]||60); if(store.users[id]){store.users[id].mutedUntil=Date.now()+min*60000;store.save();return '✅ 已 Bot 層級禁言';} return '找不到會員';}
 return '管理指令：/公告 /送幣 /加EXP /黑名單 /解除黑名單 /禁言';
}
module.exports={isAdmin,adminCommand};
