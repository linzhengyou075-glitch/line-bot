const items=[{name:'補簽卡',cat:'香蕉幣商店',price:100},{name:'彩虹冒險家',cat:'稱號兌換',price:300},{name:'彩虹光圈',cat:'特效兌換',price:500},{name:'VIP 7天',cat:'VIP',price:1500},{name:'遠距團戰券',cat:'Pokemon GO 道具',price:300}];
function shopText(){return '🎁〔蕉〕個朋友商店\n\n'+items.map(i=>`${i.cat}｜${i.name}｜${i.price}幣`).join('\n')+'\n\n輸入：購買 商品名稱';}
function buyItem(u,name){const item=items.find(i=>i.name===name); if(!item)return '找不到商品'; if((u.coins||0)<item.price)return '香蕉幣不足 🍌'; u.coins-=item.price; u.bag=u.bag||[]; u.bag.push(item.name); return `✅ 購買成功：${item.name}\n剩餘香蕉幣：${u.coins}`;}
module.exports={shopText,buyItem,items};
