const fs=require('fs'), path=require('path');
const file=path.join(__dirname,'../data/db.json');
function load(){ try{return JSON.parse(fs.readFileSync(file,'utf8'))}catch{return {users:{},admins:{},settings:{}}} }
const data=load();
data.save=()=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify({users:data.users,admins:data.admins,settings:data.settings},null,2));};
module.exports={store:data};
