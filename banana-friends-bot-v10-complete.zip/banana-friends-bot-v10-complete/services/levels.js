const titles=['初生之蕉','新芽','萌芽者','初心者','新朋友','活力新星','香蕉夥伴','歡樂旅人','聊天高手','暖心使者','人氣新秀','彩虹旅人','彩虹好友','彩虹使者','彩虹精靈','彩虹守護者','星光達人','活躍達人','榮耀之星','榮耀勇者','榮耀騎士','白金菁英','鑽石菁英','星耀菁英','榮耀領主','彩虹領主','彩虹公爵','彩虹君王','彩虹霸主','永恆之星','永恆守護者','永恆彩虹','永恆璀璨','永恆璀璨彩虹','永恆聖翼','永恆不滅','永恆璀璨彩虹不滅','彩虹神話','彩虹創世者','彩虹至高神','永恆璀璨彩虹不滅創世神'];
function getLevelInfo(exp=0){ const level=Math.min(100,Math.floor(exp/100)); const idx=Math.min(titles.length-1,Math.floor(level/2.5)); return {level,title:titles[idx],nextExp:(level+1)*100}; }
function addExp(u,n){u.exp=(u.exp||0)+n; return getLevelInfo(u.exp);}
module.exports={getLevelInfo,addExp,titles};
